package com.sharex.pro

import android.content.Context
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicInteger

/** Receive / share mode: runs the server + announces the device on the local network. */
object Host {
    val state = MutableStateFlow<ShareServer?>(null)
    val files = MutableStateFlow<List<SharedFile>>(emptyList())
    @Volatile var ownName = ""
    private var reg: NsdManager.RegistrationListener? = null

    fun start(ctx: Context, ttlMin: Int) {
        if (state.value != null) return
        val app = ctx.applicationContext
        val pin = String.format("%06d", SecureRandom().nextInt(1_000_000))
        val s = ShareServer(app, pin, ttlMin)
        s.start()
        state.value = s
        TransferService.acquire(app)
        try {
            val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
            val info = NsdServiceInfo().apply {
                serviceName = "ShareX-" + Prefs.deviceName
                serviceType = "_sharex._tcp."
                port = s.port
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
                override fun onServiceRegistered(i: NsdServiceInfo) { ownName = i.serviceName }
                override fun onServiceUnregistered(i: NsdServiceInfo) {}
            }
            reg = l
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (e: Exception) {}
    }

    fun stop(ctx: Context) {
        val s = state.value ?: return
        val app = ctx.applicationContext
        s.stop()
        state.value = null
        try {
            val nsd = app.getSystemService(Context.NSD_SERVICE) as NsdManager
            reg?.let { nsd.unregisterService(it) }
        } catch (e: Exception) {}
        reg = null
        ownName = ""
        TransferService.release(app)
    }
}

/** Finds other ShareX devices on the same Wi-Fi / hotspot (mDNS). */
class Discovery(ctx: Context) {
    private val nsd = ctx.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    val found = MutableStateFlow<List<Target>>(emptyList())
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var busy = false
    private var listener: NsdManager.DiscoveryListener? = null

    private fun next() {
        synchronized(queue) {
            if (busy) return
            val s = queue.removeFirstOrNull() ?: return
            busy = true
            try {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(si: NsdServiceInfo, e: Int) {
                        synchronized(queue) { busy = false }; next()
                    }
                    override fun onServiceResolved(si: NsdServiceInfo) {
                        val h = si.host?.hostAddress
                        if (h != null && si.serviceName != Host.ownName) {
                            found.update { l -> l.filter { it.name != si.serviceName } + Target(h, si.port, "", si.serviceName) }
                        }
                        synchronized(queue) { busy = false }; next()
                    }
                })
            } catch (e: Exception) { busy = false }
        }
    }

    fun start() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, c: Int) {}
            override fun onStopDiscoveryFailed(t: String, c: Int) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                if (s.serviceType.contains("_sharex")) { synchronized(queue) { queue.addLast(s) }; next() }
            }
            override fun onServiceLost(s: NsdServiceInfo) {
                found.update { list -> list.filter { it.name != s.serviceName } }
            }
        }
        listener = l
        try { nsd.discoverServices("_sharex._tcp.", NsdManager.PROTOCOL_DNS_SD, l) } catch (e: Exception) {}
    }

    fun stop() {
        try { listener?.let { nsd.stopServiceDiscovery(it) } } catch (e: Exception) {}
        listener = null
    }
}

/** Shared UI state: files chosen to send + connected receivers (up to 10). */
object Session {
    val files = MutableStateFlow<List<SharedFile>>(emptyList())
    val targets = MutableStateFlow<List<Target>>(emptyList())
    private val ids = AtomicInteger()
    private val main = Handler(Looper.getMainLooper())

    fun toast(c: Context, m: String) { main.post { Toast.makeText(c.applicationContext, m, Toast.LENGTH_LONG).show() } }

    fun describe(ctx: Context, uri: Uri): SharedFile {
        var n = "file"
        var s = 0L
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) n = c.getString(ni) ?: n
                    if (si >= 0 && !c.isNull(si)) s = c.getLong(si)
                }
            }
            if (s <= 0) ctx.contentResolver.openFileDescriptor(uri, "r")?.use { s = it.statSize }
        } catch (e: Exception) {}
        return SharedFile(ids.incrementAndGet(), uri, n, maxOf(s, 0L))
    }

    fun addFiles(ctx: Context, uris: List<Uri>) {
        val l = uris.map { describe(ctx, it) }
        files.update { it + l }
    }

    fun connect(ctx: Context, host: String, port: Int, auth: String) {
        if (targets.value.size >= 10) { toast(ctx, "Maximum 10 devices"); return }
        CoroutineScope(Dispatchers.IO).launch {
            val t = Sender.connect(host, port, auth)
            if (t == null) toast(ctx, "Could not connect – check PIN / same Wi-Fi")
            else {
                targets.update { l -> l.filter { it.host != t.host || it.port != t.port } + t }
                toast(ctx, "Connected: ${t.name}")
            }
        }
    }

    fun connectQr(ctx: Context, text: String) {
        try {
            val u = Uri.parse(text.trim())
            val h = u.host
            val a = u.getQueryParameter("a")
            if (h == null || a == null || u.port < 0) throw IllegalArgumentException()
            connect(ctx, h, u.port, a)
        } catch (e: Exception) { toast(ctx, "Not a ShareX QR code") }
    }
}
