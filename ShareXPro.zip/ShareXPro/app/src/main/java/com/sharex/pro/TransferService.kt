package com.sharex.pro

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicInteger

/** Keeps transfers alive in background and holds a low-latency Wi-Fi lock for best throughput. */
class TransferService : Service() {
    private var wifiLock: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        try {
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "sharex:lock").apply {
                setReferenceCounted(false); acquire()
            }
        } catch (e: Exception) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("xfer", "Transfers", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = Notification.Builder(this, "xfer")
            .setContentTitle("ShareX Pro")
            .setContentText("Sharing / transferring files…")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { wifiLock?.release() } catch (e: Exception) {}
        super.onDestroy()
    }

    companion object {
        private val count = AtomicInteger()
        fun acquire(c: Context) {
            count.incrementAndGet()
            ContextCompat.startForegroundService(c, Intent(c, TransferService::class.java))
        }
        fun release(c: Context) {
            if (count.decrementAndGet() <= 0) {
                count.set(0)
                c.stopService(Intent(c, TransferService::class.java))
            }
        }
    }
}
