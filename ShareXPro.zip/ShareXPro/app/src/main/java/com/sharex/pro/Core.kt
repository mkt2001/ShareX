package com.sharex.pro

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

const val CHUNK = 4 * 1024 * 1024
const val DEFAULT_PORT = 8765

data class SharedFile(val id: Int, val uri: Uri, val name: String, val size: Long)
data class Target(val host: String, val port: Int, val auth: String, val name: String)
data class Xfer(
    val id: String, val name: String, val total: Long, val done: Long, val speed: Long,
    val dir: String, val peer: String, val status: String, val note: String
)

class CancelledXfer : RuntimeException("Cancelled")

class ShareXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        History.init(this)
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("sharex", Context.MODE_PRIVATE) }
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var deviceName: String
        get() = sp.getString("dn", null) ?: (Build.MODEL ?: "Android")
        set(v) { sp.edit().putString("dn", v).apply() }
}

object History {
    private lateinit var f: File
    fun init(c: Context) { f = File(c.filesDir, "history.tsv") }
    private fun clean(s: String) = s.replace(Regex("[\t\n\r]"), " ")
    @Synchronized
    fun add(dir: String, name: String, size: Long, status: String, peer: String, note: String) {
        try {
            f.appendText("${System.currentTimeMillis()}\t${clean(dir)}\t${clean(name)}\t$size\t$status\t${clean(peer)}\t${clean(note)}\n")
        } catch (e: Exception) {}
    }
    @Synchronized
    fun all(): List<List<String>> =
        if (::f.isInitialized && f.exists()) f.readLines().asReversed().map { it.split('\t') }.filter { it.size >= 7 }
        else emptyList()
    @Synchronized
    fun clear() { if (::f.isInitialized) f.delete() }
}

object TransferHub {
    val items = MutableStateFlow<List<Xfer>>(emptyList())
    val live = ConcurrentHashMap<String, Progress>()
    fun put(x: Xfer) {
        items.update { l -> if (l.any { it.id == x.id }) l.map { if (it.id == x.id) x else it } else listOf(x) + l }
    }
    fun clearFinished() {
        items.update { l -> l.filter { it.status == "Active" || it.status == "Paused" } }
    }
}

/** Tracks one transfer and measures REAL throughput (bytes actually moved). */
class Progress(
    val id: String, private val name: String, private val total: Long,
    private val dir: String, private val peer: String
) {
    private val done = AtomicLong(0)
    @Volatile private var lastT = System.nanoTime()
    @Volatile private var lastB = 0L
    @Volatile private var speed = 0L
    @Volatile var paused = false
    @Volatile var cancelled = false
    @Volatile var lastAct = System.currentTimeMillis()
    @Volatile private var status = "Active"

    init { TransferHub.live[id] = this; publish() }

    fun setDone(v: Long) { done.set(v); lastB = v; lastT = System.nanoTime() }

    fun add(n: Long) {
        val d = done.addAndGet(n)
        lastAct = System.currentTimeMillis()
        val now = System.nanoTime()
        if (now - lastT > 400_000_000L) synchronized(this) {
            val t = System.nanoTime()
            if (t - lastT > 400_000_000L) {
                speed = ((d - lastB) * 1_000_000_000.0 / (t - lastT)).toLong().coerceAtLeast(0)
                lastB = d; lastT = t
                publish()
            }
        }
    }

    fun checkpoint() {
        while (paused && !cancelled) Thread.sleep(200)
        if (cancelled) throw CancelledXfer()
    }

    fun setPaused(p: Boolean) {
        paused = p
        status = if (p) "Paused" else "Active"
        speed = 0
        lastB = done.get(); lastT = System.nanoTime()
        publish()
    }

    fun cancel() { cancelled = true; paused = false }

    private fun publish() {
        TransferHub.put(Xfer(id, name, total, done.get(), if (status == "Active") speed else 0, dir, peer, status, ""))
    }

    fun finish(ok: Boolean, note: String) {
        if (ok) done.set(total)
        status = if (cancelled) "Cancelled" else if (ok) "Done" else "Failed"
        speed = 0
        TransferHub.put(Xfer(id, name, total, done.get(), 0, dir, peer, status, note))
        TransferHub.live.remove(id)
        History.add(dir, name, total, status, peer, note)
    }
}

object Net {
    fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) { emptyList() }
}

fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
    return String.format("%.1f %s", v, u[i])
}

fun fmtSpeed(bps: Long): String = String.format("%.1f MB/s (%.0f Mbps)", bps / 1048576.0, bps * 8 / 1e6)
