package com.sharex.pro

import android.content.ContentValues
import android.content.Context
import android.provider.MediaStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.channels.Channels
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

fun hex(b: ByteArray): String = b.joinToString("") { "%02x".format(it) }
fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

private fun jsonEsc(s: String): String =
    s.replace("\\", "\\\\").replace("\"", "\\\"").replace(Regex("[\\u0000-\\u001f]"), " ")

private fun safeName(n: String?): String {
    var s = File(n ?: "file").name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trimStart('.')
    if (s.isEmpty()) s = "file"
    return s.take(180)
}

/**
 * Tiny streaming HTTP server. Serves the web page for PC browsers, lists/streams shared files
 * (with HTTP Range = resume), and receives chunked uploads (4 MB chunks, parallel, resumable,
 * each chunk verified with SHA-256 when the sender provides it).
 */
class ShareServer(private val ctx: Context, val pin: String, ttlMin: Int) {
    val token: String = hex(ByteArray(16).also { SecureRandom().nextBytes(it) })
    val expiresAt: Long = if (ttlMin > 0) System.currentTimeMillis() + ttlMin * 60_000L else Long.MAX_VALUE
    var port = 0
        private set

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    private val reaper: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor()
    private val fails = ConcurrentHashMap<String, LongArray>()
    private val rx = ConcurrentHashMap<String, Progress>()
    private val locks = ConcurrentHashMap<String, Any>()
    private val rxDir: File = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "incoming").apply { mkdirs() }

    fun start() {
        if (server != null) return
        val s = try { ServerSocket(DEFAULT_PORT) } catch (e: Exception) { ServerSocket(0) }
        server = s
        port = s.localPort
        pool.execute {
            while (!s.isClosed) {
                try {
                    val c = s.accept()
                    c.tcpNoDelay = true
                    pool.execute { handle(c) }
                } catch (e: Exception) { if (s.isClosed) break }
            }
        }
        reaper.scheduleWithFixedDelay({
            val now = System.currentTimeMillis()
            for ((k, p) in rx) {
                if (now - p.lastAct > 20_000) {
                    rx.remove(k)
                    p.finish(false, "Interrupted – sender can resume from where it stopped")
                }
            }
        }, 5, 5, TimeUnit.SECONDS)
    }

    fun stop() {
        try { server?.close() } catch (e: Exception) {}
        server = null
        reaper.shutdownNow()
        pool.shutdownNow()
        for ((_, p) in rx) p.finish(false, "Server stopped")
        rx.clear()
    }

    private fun readLine(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) { sb.append(b.toChar()); if (sb.length > 8192) return null }
        }
        return sb.toString()
    }

    private fun handle(c: Socket) {
        c.use { sock ->
            try {
                sock.soTimeout = 30_000
                val inp = BufferedInputStream(sock.getInputStream(), 1 shl 16)
                val out = BufferedOutputStream(sock.getOutputStream(), 1 shl 16)
                while (true) {
                    val reqLine = readLine(inp) ?: break
                    if (reqLine.isEmpty()) break
                    val parts = reqLine.split(" ")
                    if (parts.size < 2) break
                    val headers = HashMap<String, String>()
                    while (true) {
                        val h = readLine(inp) ?: return
                        if (h.isEmpty()) break
                        val i = h.indexOf(':')
                        if (i > 0) headers[h.substring(0, i).trim().lowercase()] = h.substring(i + 1).trim()
                    }
                    val keep = route(parts[0], parts[1], headers, inp, out, sock)
                    out.flush()
                    if (!keep) break
                }
            } catch (e: Exception) {}
        }
    }

    private fun send(out: OutputStream, code: Int, ctype: String, body: ByteArray, extra: String = "") {
        val msg = when (code) {
            200 -> "OK"; 400 -> "Bad Request"; 401 -> "Unauthorized"; 404 -> "Not Found"
            410 -> "Gone"; 416 -> "Range Not Satisfiable"; 422 -> "Unprocessable"; 429 -> "Too Many Requests"
            else -> "Error"
        }
        out.write(
            ("HTTP/1.1 $code $msg\r\nContent-Type: $ctype\r\nContent-Length: ${body.size}\r\n" +
                "Cache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\n$extra\r\n").toByteArray()
        )
        out.write(body)
    }

    private fun authorize(ip: String, a: String?): Int {
        val now = System.currentTimeMillis()
        if (now > expiresAt) return 410
        val f = fails[ip]
        if (f != null && f[0] >= 8 && now - f[1] < 60_000) return 429
        if (a != null && (MessageDigest.isEqual(a.toByteArray(), token.toByteArray()) ||
                    MessageDigest.isEqual(a.toByteArray(), pin.toByteArray()))
        ) { fails.remove(ip); return 0 }
        val n = fails.getOrPut(ip) { LongArray(2) }
        synchronized(n) { if (now - n[1] > 60_000) n[0] = 0; n[0]++; n[1] = now }
        return 401
    }

    private fun route(
        method: String, target: String, h: Map<String, String>,
        inp: InputStream, out: OutputStream, sock: Socket
    ): Boolean {
        val path = target.substringBefore('?')
        val p = HashMap<String, String>()
        for (kv in target.substringAfter('?', "").split('&')) {
            if (kv.isEmpty()) continue
            try { p[kv.substringBefore('=')] = URLDecoder.decode(kv.substringAfter('=', ""), "UTF-8") } catch (e: Exception) {}
        }
        val ip = sock.inetAddress?.hostAddress ?: "?"
        if (path == "/" || path == "/index.html") {
            send(out, 200, "text/html; charset=utf-8", PAGE.toByteArray()); return true
        }
        val code = authorize(ip, p["a"])
        if (code != 0) { send(out, code, "text/plain", "denied".toByteArray()); return false }

        when {
            path == "/api/ping" -> {
                val n = Prefs.deviceName.replace(Regex("[\"\\\\]"), "")
                send(out, 200, "application/json", "{\"name\":\"$n\"}".toByteArray())
            }
            path == "/api/list" -> {
                val sb = StringBuilder("[")
                Host.files.value.forEachIndexed { i, f ->
                    if (i > 0) sb.append(',')
                    sb.append("{\"id\":${f.id},\"name\":\"${jsonEsc(f.name)}\",\"size\":${f.size}}")
                }
                sb.append(']')
                send(out, 200, "application/json", sb.toString().toByteArray())
            }
            path.startsWith("/dl/") -> return download(path, h, out, ip)
            path == "/api/have" -> {
                val name = safeName(p["name"]); val total = p["total"]?.toLongOrNull() ?: 0L
                send(out, 200, "application/json", haveSet(name, total).joinToString(",", "[", "]").toByteArray())
            }
            path == "/api/done" -> return finalizeUpload(p, out, ip)
            path == "/up" && method == "PUT" -> return upload(p, h, inp, out, ip)
            else -> send(out, 404, "text/plain", "not found".toByteArray())
        }
        return true
    }

    // ---------- download (phone -> PC / peer), HTTP Range = resume ----------
    private fun download(path: String, h: Map<String, String>, out: OutputStream, ip: String): Boolean {
        val id = path.removePrefix("/dl/").toIntOrNull()
        val f = Host.files.value.find { it.id == id }
        if (f == null) { send(out, 404, "text/plain", "not found".toByteArray()); return true }
        val total = f.size
        var start = 0L
        var end = total - 1
        var code = 200
        h["range"]?.let {
            val m = Regex("bytes=(\\d*)-(\\d*)").matchEntire(it.trim())
            if (m != null) {
                val s = m.groupValues[1]; val e = m.groupValues[2]
                if (s.isNotEmpty()) { start = s.toLong(); if (e.isNotEmpty()) end = minOf(e.toLong(), total - 1) }
                else if (e.isNotEmpty()) start = maxOf(0L, total - e.toLong())
                code = 206
            }
        }
        if (total > 0 && (start >= total || start > end)) {
            send(out, 416, "text/plain", ByteArray(0), "Content-Range: bytes */$total\r\n"); return true
        }
        val len = if (total == 0L) 0L else end - start + 1
        val head = StringBuilder("HTTP/1.1 $code ${if (code == 206) "Partial Content" else "OK"}\r\n")
        head.append("Content-Type: application/octet-stream\r\nContent-Length: $len\r\nAccept-Ranges: bytes\r\n")
        if (code == 206) head.append("Content-Range: bytes $start-$end/$total\r\n")
        head.append("Content-Disposition: attachment; filename*=UTF-8''${enc(f.name).replace("+", "%20")}\r\n")
        head.append("X-Content-Type-Options: nosniff\r\n\r\n")
        out.write(head.toString().toByteArray())
        val prog = Progress(UUID.randomUUID().toString(), f.name, total, "Served", ip)
        prog.setDone(start)
        var left = len
        try {
            ctx.contentResolver.openFileDescriptor(f.uri, "r")!!.use { pfd ->
                val ch = FileInputStream(pfd.fileDescriptor).channel
                ch.position(start)
                val buf = ByteArray(1 shl 20)
                val bb = ByteBuffer.wrap(buf)
                while (left > 0) {
                    bb.clear(); bb.limit(minOf(buf.size.toLong(), left).toInt())
                    val n = ch.read(bb)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    left -= n
                    prog.add(n.toLong())
                }
                out.flush()
            }
            prog.finish(left == 0L, if (left == 0L) "Sent to $ip" else "Incomplete")
        } catch (e: Exception) {
            prog.finish(false, "Interrupted – client can resume")
            throw e
        }
        return true
    }

    // ---------- upload (peer / browser -> phone) ----------
    private fun part(name: String) = File(rxDir, "$name.part")
    private fun idxFile(name: String) = File(rxDir, "$name.idx")

    private fun haveSet(name: String, total: Long): Set<Int> {
        val part = part(name); val idx = idxFile(name)
        if (part.exists() && part.length() != total) { part.delete(); idx.delete() }
        if (!part.exists()) { idx.delete(); return emptySet() }
        return if (idx.exists()) idx.readLines().mapNotNull { it.trim().toIntOrNull() }.toSet() else emptySet()
    }

    private fun upload(p: Map<String, String>, h: Map<String, String>, inp: InputStream, out: OutputStream, ip: String): Boolean {
        val name = safeName(p["name"])
        val total = p["total"]?.toLongOrNull()
        val idx = p["idx"]?.toIntOrNull()
        val len = h["content-length"]?.toLongOrNull()
        if (total == null || idx == null || len == null || total <= 0 || idx < 0) {
            send(out, 400, "text/plain", "bad".toByteArray()); return false
        }
        val off = idx.toLong() * CHUNK
        if (off >= total || len != minOf(CHUNK.toLong(), total - off)) {
            send(out, 400, "text/plain", "bad chunk".toByteArray()); return false
        }
        val lock = locks.computeIfAbsent(name) { Any() }
        val prog = rx.computeIfAbsent("$name:$total") {
            val existing = haveSet(name, total).size.toLong() * CHUNK
            Progress(UUID.randomUUID().toString(), name, total, "Received", ip).also { it.setDone(minOf(existing, total)) }
        }
        val wanted = h["x-sha256"]
        val md = if (wanted != null) MessageDigest.getInstance("SHA-256") else null
        RandomAccessFile(part(name), "rw").use { raf ->
            if (raf.length() != total) synchronized(lock) { if (raf.length() != total) raf.setLength(total) }
            raf.seek(off)
            val buf = ByteArray(256 * 1024)
            var left = len
            while (left > 0) {
                val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) throw EOFException()
                raf.write(buf, 0, n)
                md?.update(buf, 0, n)
                left -= n
                prog.add(n.toLong())
            }
        }
        if (md != null && !hex(md.digest()).equals(wanted, ignoreCase = true)) {
            prog.add(-len)
            send(out, 422, "text/plain", "hash mismatch".toByteArray()); return true
        }
        synchronized(lock) { FileOutputStream(idxFile(name), true).use { it.write("$idx\n".toByteArray()) } }
        send(out, 200, "text/plain", "ok".toByteArray())
        return true
    }

    private fun finalizeUpload(p: Map<String, String>, out: OutputStream, ip: String): Boolean {
        val name = safeName(p["name"])
        val total = p["total"]?.toLongOrNull()
        if (total == null || total < 0) { send(out, 400, "text/plain", "bad".toByteArray()); return false }
        val part = part(name)
        if (total == 0L && !part.exists()) part.createNewFile()
        val n = ((total + CHUNK - 1) / CHUNK).toInt()
        val have = haveSet(name, total)
        if (!part.exists() || !(0 until n).all { it in have }) {
            send(out, 400, "text/plain", "incomplete".toByteArray()); return true
        }
        var fin = File(rxDir, name)
        if (fin.exists()) fin = File(rxDir, "${System.currentTimeMillis()}_$name")
        part.renameTo(fin)
        idxFile(name).delete()
        val sha = sha256(fin)
        val saved = saveToDownloads(fin, name)
        val prog = rx.remove("$name:$total")
        val where = if (saved) "saved in Downloads/ShareX" else fin.absolutePath
        if (prog != null) prog.finish(true, "SHA-256 ${sha.take(16)}… · $where")
        else History.add("Received", name, total, "Done", ip, "SHA-256 ${sha.take(16)}… · $where")
        if (saved) fin.delete()
        send(out, 200, "application/json", "{\"sha256\":\"$sha\"}".toByteArray())
        return true
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { s ->
            val buf = ByteArray(1 shl 20)
            while (true) { val r = s.read(buf); if (r < 0) break; md.update(buf, 0, r) }
        }
        return hex(md.digest())
    }

    private fun saveToDownloads(src: File, name: String): Boolean = try {
        val r = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/ShareX")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)!!
        r.openOutputStream(uri)!!.use { os ->
            FileInputStream(src).channel.use { ch ->
                val w = Channels.newChannel(os)
                var pos = 0L
                val size = ch.size()
                while (pos < size) pos += ch.transferTo(pos, size - pos, w)
            }
        }
        v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0)
        r.update(uri, v, null, null)
        true
    } catch (e: Exception) { false }
}
