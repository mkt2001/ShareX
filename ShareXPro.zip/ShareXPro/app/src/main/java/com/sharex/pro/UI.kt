package com.sharex.pro

import android.Manifest
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun LazyListScope.col(content: @Composable ColumnScope.() -> Unit) {
    item { Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() } }
}

enum class Screen(val title: String) {
    Home("ShareX Pro"), Send("Send files"), Receive("Receive / Share"), Nearby("Nearby devices"),
    Transfers("Transfers"), History("History"), Settings("Settings")
}

@Composable
fun App() {
    var theme by remember { mutableIntStateOf(Prefs.theme) }
    var screen by remember { mutableStateOf(Screen.Home) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    BackHandler(screen != Screen.Home) { screen = Screen.Home }
    ShareXTheme(theme) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                if (screen != Screen.Home) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { screen = Screen.Home }) { Text("←", fontSize = 24.sp) }
                        Text(screen.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                }
                when (screen) {
                    Screen.Home -> HomeScreen { screen = it }
                    Screen.Send -> SendScreen { screen = it }
                    Screen.Receive -> ReceiveScreen()
                    Screen.Nearby -> NearbyScreen { screen = Screen.Send }
                    Screen.Transfers -> TransfersScreen()
                    Screen.History -> HistoryScreen()
                    Screen.Settings -> SettingsScreen(theme) { theme = it; Prefs.theme = it }
                }
            }
        }
    }
}

@Composable
fun Tile(emoji: String, label: String, c1: Color, c2: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(112.dp).clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(listOf(c1, c2))).clickable(onClick = onClick).padding(16.dp)
    ) {
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(emoji, fontSize = 30.sp)
            Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
fun HomeScreen(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) { Session.addFiles(ctx, uris); go(Screen.Send) }
    }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r ->
        r.contents?.let { Session.connectQr(ctx, it); go(Screen.Send) }
    }
    val openScan = {
        scan.launch(ScanOptions().apply { setDesiredBarcodeFormats(ScanOptions.QR_CODE); setBeepEnabled(false); setPrompt("Scan the QR shown on the other device") })
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("⚡ ShareX Pro", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
        Text("Fast. Private. No internet needed.", fontSize = 14.sp)
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF5B3DF5), Color(0xFFFF4F9A))))
                .clickable { pick.launch(arrayOf("*/*")) }.padding(24.dp)
        ) {
            Column {
                Text("🚀 One-Tap Send", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                Text("Tap → choose files → pick device(s) → send", color = Color.White, fontSize = 14.sp)
            }
        }
        val tiles = listOf(
            Triple("📤", "Send", Pair(Color(0xFFFF9500), Color(0xFFFF5E3A))) to { go(Screen.Send) },
            Triple("📥", "Receive / Share", Pair(Color(0xFF00C853), Color(0xFF009688))) to { go(Screen.Receive) },
            Triple("📡", "Nearby", Pair(Color(0xFF2979FF), Color(0xFF00B0FF))) to { go(Screen.Nearby) },
            Triple("📷", "Scan QR", Pair(Color(0xFF8E24AA), Color(0xFF5E35B1))) to { openScan() },
            Triple("⚡", "Transfers", Pair(Color(0xFFE91E63), Color(0xFFFF5252))) to { go(Screen.Transfers) },
            Triple("🕘", "History", Pair(Color(0xFF00897B), Color(0xFF26A69A))) to { go(Screen.History) },
            Triple("⚙️", "Settings", Pair(Color(0xFF546E7A), Color(0xFF78909C))) to { go(Screen.Settings) }
        )
        tiles.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                row.forEach { (t, action) ->
                    Tile(t.first, t.second, t.third.first, t.third.second, Modifier.weight(1f)) { action() }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text("PC / browser: open Receive / Share, then type the shown address in the PC browser.", fontSize = 12.sp)
    }
}

@Composable
fun SendScreen(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val files by Session.files.collectAsState()
    val targets by Session.targets.collectAsState()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) Session.addFiles(ctx, uris)
    }
    val scan = rememberLauncherForActivityResult(ScanContract()) { r -> r.contents?.let { Session.connectQr(ctx, it) } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        col {
            Text("1. Files", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Button(onClick = { pick.launch(arrayOf("*/*")) }) { Text("➕ Add files") }
        }
        items(files, key = { it.id }) { f ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(f.name, maxLines = 1, fontWeight = FontWeight.SemiBold); Text(fmtSize(f.size), fontSize = 12.sp) }
                    TextButton(onClick = { Session.files.update { l -> l.filter { it.id != f.id } } }) { Text("✖") }
                }
            }
        }
        col {
            Text("2. Devices (up to 10 at once)", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { go(Screen.Nearby) }) { Text("📡 Nearby") }
                Button(onClick = { scan.launch(ScanOptions().apply { setDesiredBarcodeFormats(ScanOptions.QR_CODE); setBeepEnabled(false) }) }) { Text("📷 Scan QR") }
            }
        }
        items(targets, key = { it.host + ":" + it.port }) { t ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("✅ " + t.name, fontWeight = FontWeight.SemiBold); Text("${t.host}:${t.port}", fontSize = 12.sp) }
                    TextButton(onClick = { Session.targets.update { l -> l.filter { it != t } } }) { Text("✖") }
                }
            }
        }
        col {
            Button(
                enabled = files.isNotEmpty() && targets.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().height(56.dp),
                onClick = { Sender.send(ctx, targets, files); Session.files.value = emptyList(); go(Screen.Transfers) }
            ) { Text("🚀 Send to ${targets.size} device(s)", fontSize = 18.sp) }
        }
    }
}

@Composable
fun NearbyScreen(onConnected: () -> Unit) {
    val ctx = LocalContext.current
    val disc = remember { Discovery(ctx) }
    DisposableEffect(Unit) { disc.start(); onDispose { disc.stop() } }
    val found by disc.found.collectAsState()
    var sel by remember { mutableStateOf<Target?>(null) }
    var pin by remember { mutableStateOf("") }
    var ip by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        col {
            Text("On the other phone open Receive / Share. It appears here. Tap it and type its 6-digit PIN.", fontSize = 14.sp)
        }
        if (found.isEmpty()) col { Text("🔍 Searching… (both devices must be on the same Wi-Fi or hotspot)") }
        items(found, key = { it.name }) { t ->
            Card(Modifier.fillMaxWidth().clickable { sel = t }) {
                Column(Modifier.padding(14.dp)) { Text("📱 " + t.name, fontWeight = FontWeight.Bold); Text("${t.host}:${t.port}", fontSize = 12.sp) }
            }
        }
        col {
            Text("Manual connect (IP[:port] + PIN)", fontWeight = FontWeight.Bold)
            OutlinedTextField(ip, { ip = it }, label = { Text("192.168.1.20") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                pin2, { pin2 = it.filter(Char::isDigit).take(6) }, label = { Text("PIN") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), modifier = Modifier.fillMaxWidth()
            )
            Button(onClick = {
                val hp = ip.trim().split(":")
                Session.connect(ctx, hp[0], hp.getOrNull(1)?.toIntOrNull() ?: DEFAULT_PORT, pin2)
                onConnected()
            }) { Text("Connect") }
        }
    }
    val s = sel
    if (s != null) {
        AlertDialog(
            onDismissRequest = { sel = null },
            title = { Text("PIN for ${s.name}") },
            text = {
                OutlinedTextField(
                    pin, { pin = it.filter(Char::isDigit).take(6) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
                )
            },
            confirmButton = {
                TextButton(onClick = { Session.connect(ctx, s.host, s.port, pin); sel = null; pin = ""; onConnected() }) { Text("Connect") }
            },
            dismissButton = { TextButton(onClick = { sel = null }) { Text("Cancel") } }
        )
    }
}

fun makeQr(text: String, size: Int = 720): Bitmap {
    val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (m.get(x, y)) AColor.BLACK else AColor.WHITE)
    return bmp
}

@Composable
fun ReceiveScreen() {
    val ctx = LocalContext.current
    val server by Host.state.collectAsState()
    val shared by Host.files.collectAsState()
    var ttl by remember { mutableIntStateOf(60) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) Host.files.update { it + uris.map { u -> Session.describe(ctx, u) } }
    }
    val s = server
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (s == null) {
            col {
                Text("Private link expiry", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "Never", 10 to "10 min", 60 to "1 hour", 1440 to "24 h").forEach { (m, label) ->
                        FilterChip(selected = ttl == m, onClick = { ttl = m }, label = { Text(label) })
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { Host.start(ctx, ttl) }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
                    Text("📥 Start receiving / sharing", fontSize = 18.sp)
                }
            }
        } else {
            val ips = Net.localIps()
            col {
                if (ips.isEmpty()) {
                    Text("⚠ Not connected to Wi-Fi. Join a Wi-Fi or turn on your phone hotspot on the other device (no internet needed).")
                } else {
                    val url = "http://${ips[0]}:${s.port}/?a=${s.token}"
                    val bmp = remember(url) { makeQr(url) }
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Scan to connect", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Image(bmp.asImageBitmap(), contentDescription = "QR", modifier = Modifier.size(240.dp))
                            Text("PIN", fontSize = 12.sp)
                            Text(s.pin, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                            ips.forEach { Text("PC browser:  http://$it:${s.port}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                            Text(
                                if (s.expiresAt == Long.MAX_VALUE) "Link never expires" else "Link expires at " +
                                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(s.expiresAt)),
                                fontSize = 12.sp
                            )
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { Host.stop(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("⏹ Stop") }
            }
        }
        col {
            Text("Files for browser / PC download", fontWeight = FontWeight.Bold)
            Text("Received files are saved in Downloads/ShareX.", fontSize = 12.sp)
            Button(onClick = { pick.launch(arrayOf("*/*")) }) { Text("➕ Add files to share") }
        }
        items(shared, key = { it.id }) { f ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(f.name, maxLines = 1); Text(fmtSize(f.size), fontSize = 12.sp) }
                    TextButton(onClick = { Host.files.update { l -> l.filter { it.id != f.id } } }) { Text("✖") }
                }
            }
        }
    }
}

@Composable
fun XferCard(x: Xfer) {
    val pct = if (x.total > 0) (x.done.toFloat() / x.total).coerceIn(0f, 1f) else 1f
    val live = TransferHub.live[x.id]
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp)) {
            val icon = when (x.dir) { "Sent" -> "📤 "; "Received" -> "📥 "; else -> "🌐 " }
            Text(icon + x.name, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("${x.dir} · ${x.peer} · ${fmtSize(x.total)}", fontSize = 12.sp)
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            val eta = if (x.speed > 0) " · ETA ${(x.total - x.done) / x.speed}s" else ""
            val speed = if (x.status == "Active") " · ${fmtSpeed(x.speed)}$eta" else ""
            Text("${(pct * 100).toInt()}% · ${x.status}$speed", fontSize = 13.sp)
            if (x.note.isNotEmpty()) Text(x.note, fontSize = 12.sp)
            if (live != null && x.dir == "Sent") {
                Row {
                    TextButton(onClick = { live.pause(!live.paused) }) { Text(if (live.paused) "▶ Resume" else "⏸ Pause") }
                    TextButton(onClick = { live.cancel() }) { Text("✖ Cancel") }
                }
            }
        }
    }
}

@Composable
fun TransfersScreen() {
    val list by TransferHub.items.collectAsState()
    val total = list.filter { it.status == "Active" }.sumOf { it.speed }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        col {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Live throughput (measured)", color = Color.White, fontSize = 12.sp)
                    Text(fmtSpeed(total), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            TextButton(onClick = { TransferHub.clearFinished() }) { Text("Clear finished") }
        }
        if (list.isEmpty()) col { Text("No transfers yet.") }
        items(list, key = { it.id }) { XferCard(it) }
    }
}

@Composable
fun HistoryScreen() {
    var rows by remember { mutableStateOf(History.all()) }
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        col { TextButton(onClick = { History.clear(); rows = emptyList() }) { Text("🗑 Clear history") } }
        if (rows.isEmpty()) col { Text("Nothing here yet.") }
        items(rows) { r ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(r[2], fontWeight = FontWeight.SemiBold, maxLines = 1)
                    Text("${r[1]} · ${r[4]} · ${fmtSize(r[3].toLongOrNull() ?: 0)} · ${r[5]}", fontSize = 12.sp)
                    Text(fmt.format(Date(r[0].toLongOrNull() ?: 0)) + if (r[6].isNotBlank()) " · " + r[6] else "", fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(theme: Int, onTheme: (Int) -> Unit) {
    var name by remember { mutableStateOf(Prefs.deviceName) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Device name", fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it.take(30); Prefs.deviceName = name.ifBlank { "Android" } }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text("Theme", fontWeight = FontWeight.Bold)
        listOf("System", "Light", "Dark", "AMOLED black").forEachIndexed { i, label ->
            Row(Modifier.fillMaxWidth().clickable { onTheme(i) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = theme == i, onClick = { onTheme(i) })
                Text(label)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Security notes", fontWeight = FontWeight.Bold)
        Text(
            "• Access needs the QR token or the 6-digit PIN (8 wrong tries = 1 min block).\n" +
                "• Every chunk is checked with SHA-256; the finished file hash is shown in History.\n" +
                "• Traffic on your Wi-Fi is not yet encrypted (see SECURITY.md) – share on networks you trust.\n" +
                "• Received files are never opened or executed automatically.",
            fontSize = 13.sp
        )
    }
}
