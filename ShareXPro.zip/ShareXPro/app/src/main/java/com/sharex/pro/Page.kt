package com.sharex.pro

/** Web page served to PC / other-phone browsers. No external resources, works offline. */
val PAGE: String = """
<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>ShareX Pro</title>
<style>
body{font-family:system-ui,sans-serif;margin:0;background:#f4f1ff;color:#1b1340}
header{background:linear-gradient(135deg,#5b3df5,#ff4f9a);color:#fff;padding:22px}
h1{margin:0;font-size:26px} main{padding:16px;max-width:760px;margin:auto}
.card{background:#fff;border-radius:18px;padding:16px;margin-bottom:16px;box-shadow:0 2px 10px #0002}
a.f{display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid #eee;color:#5b3df5;text-decoration:none;font-weight:600}
label.b{background:linear-gradient(135deg,#00b894,#00cec9);color:#fff;border-radius:14px;padding:14px 22px;font-size:16px;font-weight:700;cursor:pointer;display:inline-block}
#drop{border:3px dashed #5b3df5;border-radius:18px;padding:28px;text-align:center}
.row{padding:6px 0;font-size:14px}
</style></head><body>
<header><h1>⚡ ShareX Pro</h1><div>Fast file sharing with your phone</div></header>
<main>
<div class="card"><h3>📥 Files on the phone (tap to download)</h3><div id="files">Loading…</div></div>
<div class="card"><h3>📤 Send files to the phone</h3>
<div id="drop">Drop files here<br><br><label class="b">Choose files<input id="pick" type="file" multiple hidden></label></div>
<div id="log"></div></div>
</main>
<script>
var A=new URLSearchParams(location.search).get('a');
if(!A){A=prompt('Enter the 6-digit PIN shown on the phone');}
var C=4194304;
function q(p,x){return fetch(p+'?a='+encodeURIComponent(A)+(x||''));}
function sz(b){var u=['B','KB','MB','GB','TB'],i=0;while(b>=1024&&i<4){b/=1024;i++;}return b.toFixed(i?1:0)+' '+u[i];}
function load(){
  q('/api/list').then(function(r){if(!r.ok)throw r.status;return r.json();}).then(function(l){
    var h='';
    if(!l.length)h='<div class="row">No files shared from the phone yet.</div>';
    l.forEach(function(f){h+='<a class="f" href="/dl/'+f.id+'?a='+encodeURIComponent(A)+'"><span>'+f.name.replace(/</g,'&lt;')+'</span><span>'+sz(f.size)+'</span></a>';});
    document.getElementById('files').innerHTML=h;
  }).catch(function(e){document.getElementById('files').textContent='Access denied or link expired ('+e+')';});
}
async function up(f,row){
  var nm=encodeURIComponent(f.name),tot=f.size,n=Math.ceil(tot/C);
  var have=await (await q('/api/have','&name='+nm+'&total='+tot)).json();
  var todo=[];for(var i=0;i<n;i++){if(have.indexOf(i)<0)todo.push(i);}
  var dn=(n-todo.length)*C,t0=Date.now(),b0=dn;
  async function worker(){
    while(todo.length){
      var i=todo.shift(),blob=f.slice(i*C,Math.min(tot,(i+1)*C)),ok=false;
      for(var t=0;t<4&&!ok;t++){
        try{var rr=await fetch('/up?a='+encodeURIComponent(A)+'&name='+nm+'&total='+tot+'&idx='+i,{method:'PUT',body:blob});ok=rr.ok;}catch(e){}
      }
      if(!ok)throw new Error('chunk '+i+' failed');
      dn+=blob.size;
      var mbs=((dn-b0)/1048576)/(((Date.now()-t0)/1000)+0.001);
      row.textContent=f.name+' — '+Math.min(100,Math.floor(dn*100/Math.max(tot,1)))+'% · '+mbs.toFixed(1)+' MB/s ('+(mbs*8).toFixed(0)+' Mbps)';
    }
  }
  await Promise.all([worker(),worker(),worker(),worker()]);
  var r2=await q('/api/done','&name='+nm+'&total='+tot);
  row.textContent=(r2.ok?'✅ ':'❌ ')+f.name+' ('+sz(tot)+')'+(r2.ok?' sent':' failed');
}
async function send(files){
  var log=document.getElementById('log');
  for(var k=0;k<files.length;k++){
    var row=document.createElement('div');row.className='row';row.textContent=files[k].name+' …';log.appendChild(row);
    try{await up(files[k],row);}catch(e){row.textContent='⚠ '+files[k].name+': '+e.message+' — choose it again to resume';}
  }
}
document.getElementById('pick').onchange=function(e){send(e.target.files);};
var d=document.getElementById('drop');
d.ondragover=function(e){e.preventDefault();};
d.ondrop=function(e){e.preventDefault();send(e.dataTransfer.files);};
load();
</script></body></html>
""".trimIndent()
