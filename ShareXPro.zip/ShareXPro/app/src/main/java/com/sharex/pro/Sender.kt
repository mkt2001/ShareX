package com.sharex.pro

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.io.EOFException
import java.io.FileInputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

class FatalIo(m: String) : IOException(m)

/**
 * Sends files to one or many receivers (group sharing) over plain LAN HTTP.
 * Files are cut into 4 MB chunks, sent by parallel workers, every chunk carries a SHA-256.
 * Chunks already stored by the receiver are skipped = smart resume.
 */
object Sender {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun connect(host: String, port: Int, auth: String): Target? = try {
        val c = URL("http://$host:$port/api/ping?a=${enc(auth)}").openConnection() as HttpURLConnection
        c.connectTimeout = 4000; c.readTimeout = 4000
        if (c.responseCode != 200) { c.errorStream?.close(); null }
        else {
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val name = Regex("\"name\":\"([^\"]*)\"").find(body)?.groupValues?.get(1) ?: host
            Target(host, port, auth, name)
        }
    } catch (e: Exception) { null }

    fun send(ctx: Context, targets: List<Target>, files: List<SharedFile>) {
        val app = ctx.applicationContext
        TransferService.acquire(app)
        scope.launch {
            try {
                val workers = if (targets.size > 2) 2 else 4
                targets.map { t -> async { for (f in files) sendFile(app, t, f, workers) } }.awaitAll()
            } finally {
                TransferService.release(app)
            }
        }
    }

    private fun get(t: Target, path: String, extra: String): String {
        val c = URL("http://${t.host}:${t.port}$path?a=${enc(t.auth)}$extra").openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 0 // receiver may need time to hash very large files
        val code = c.responseCode
        if (code != 200) {
            c.errorStream?.close()
            throw FatalIo(when (code) { 401 -> "Wrong PIN"; 410 -> "Link expired"; 429 -> "Too many attempts"; else -> "HTTP $code" })
        }
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    private suspend fun sendFile(ctx: Context, t: Target, f: SharedFile, workers: Int) {
        val p = Progress(UUID.randomUUID().toString(), f.name, f.size, "Sent", t.name)
        try {
            val total = f.size
            val n = ((total + CHUNK - 1) / CHUNK).toInt()
            val have = Regex("\\d+").findAll(get(t, "/api/have", "&name=${enc(f.name)}&total=$total"))
                .map { it.value.toInt() }.toSet()
            p.setDone(minOf(total, have.size.toLong() * CHUNK))
            val todo = ConcurrentLinkedQueue<Int>((0 until n).filter { it !in have })
            if (todo.isNotEmpty()) {
                ctx.contentResolver.openFileDescriptor(f.uri, "r")!!.use { pfd ->
                    val ch = FileInputStream(pfd.fileDescriptor).channel
                    coroutineScope {
                        (0 until minOf(workers, todo.size)).map {
                            async {
                                val buf = ByteArray(CHUNK)
                                val bb = ByteBuffer.wrap(buf)
                                while (true) {
                                    val i = todo.poll() ?: break
                                    p.checkpoint()
                                    sendChunk(t, f, i, ch, buf, bb, p)
                                }
                            }
                        }.awaitAll()
                    }
                }
            }
            val resp = get(t, "/api/done", "&name=${enc(f.name)}&total=$total")
            val sha = Regex("\"sha256\":\"([0-9a-f]{64})\"").find(resp)?.groupValues?.get(1)?.take(12) ?: ""
            p.finish(true, "Chunks verified (SHA-256) · file hash $sha…")
        } catch (e: CancelledXfer) {
            p.finish(false, "Cancelled")
        } catch (e: Exception) {
            p.finish(false, (e.message ?: "Error") + " – send again to resume")
        }
    }

    private fun sendChunk(t: Target, f: SharedFile, i: Int, ch: FileChannel, buf: ByteArray, bb: ByteBuffer, p: Progress) {
        val off = i.toLong() * CHUNK
        val len = minOf(CHUNK.toLong(), f.size - off).toInt()
        bb.clear(); bb.limit(len)
        var pos = off
        while (bb.hasRemaining()) {
            val r = ch.read(bb, pos)
            if (r < 0) throw EOFException("File changed while sending")
            pos += r
        }
        val md = MessageDigest.getInstance("SHA-256")
        md.update(buf, 0, len)
        val sha = hex(md.digest())
        var err = "unknown"
        for (attempt in 0 until 4) {
            p.checkpoint()
            var added = 0L
            try {
                val c = URL("http://${t.host}:${t.port}/up?a=${enc(t.auth)}&name=${enc(f.name)}&total=${f.size}&idx=$i")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "PUT"
                c.doOutput = true
                c.setFixedLengthStreamingMode(len)
                c.connectTimeout = 8000
                c.readTimeout = 60000
                c.setRequestProperty("X-Sha256", sha)
                c.outputStream.use { os ->
                    var o = 0
                    while (o < len) {
                        p.checkpoint()
                        val n = minOf(262144, len - o)
                        os.write(buf, o, n)
                        o += n; added += n
                        p.add(n.toLong())
                    }
                }
                val code = c.responseCode
                if (code == 200) { c.inputStream.use { it.readBytes() }; return }
                c.errorStream?.close()
                if (code == 401 || code == 410 || code == 429) throw FatalIo("Receiver refused (HTTP $code)")
                err = "HTTP $code"
            } catch (e: CancelledXfer) { throw e }
            catch (e: FatalIo) { throw e }
            catch (e: IOException) { err = e.message ?: "network" }
            p.add(-added)
            Thread.sleep(400L * (attempt + 1))
        }
        throw IOException("Chunk $i failed: $err")
    }
}
