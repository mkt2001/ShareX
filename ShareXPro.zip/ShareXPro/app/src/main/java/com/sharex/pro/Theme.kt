package com.sharex.pro

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** mode: 0 = System, 1 = Light, 2 = Dark, 3 = AMOLED black */
@Composable
fun ShareXTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 0 -> isSystemInDarkTheme(); 2, 3 -> true; else -> false }
    val scheme = if (dark) {
        darkColorScheme(
            primary = Color(0xFF9D8CFF), secondary = Color(0xFFFF7EB6),
            background = if (mode == 3) Color.Black else Color(0xFF14102B),
            surface = if (mode == 3) Color(0xFF0B0B0B) else Color(0xFF1E1840),
            surfaceVariant = if (mode == 3) Color(0xFF151515) else Color(0xFF2A2357)
        )
    } else {
        lightColorScheme(
            primary = Color(0xFF5B3DF5), secondary = Color(0xFFFF4F9A),
            background = Color(0xFFF4F1FF), surface = Color.White, surfaceVariant = Color(0xFFE9E4FF)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
