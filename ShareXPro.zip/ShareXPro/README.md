# ShareX Pro

Fast file sharing for Android ↔ Android, Android → Windows PC, and PC → Android (via browser). Works without internet (same Wi-Fi or phone hotspot).

## Build the APK (GitHub)
1. Create a GitHub repo and upload everything from this folder (keep `.github/workflows/android.yml`).
2. Push to `main`. GitHub Actions builds `ShareXPro-debug.apk` and `ShareXPro-release.apk`.
3. Download from **Actions → latest run → Artifacts**, or from the repo's **Releases** (created automatically).

Local build: Android Studio (JDK 17) → open folder → Build → Build APK(s).

## How to use
- **Android → Android**: Receiver opens *Receive / Share* → shows QR + PIN. Sender taps *One-Tap Send* → picks files → *Scan QR* (or *Nearby* + PIN) → *Send*.
- **Group sharing**: add up to 10 devices on the Send screen, send once to all.
- **Phone → PC**: on phone *Receive / Share*, add files, start. On the PC browser open the shown `http://IP:8765`, enter PIN, click the file.
- **PC → Phone**: same page in the PC browser, drop files in "Send files to the phone". They land in `Downloads/ShareX` on the phone.
- **Private links**: choose an expiry (10 min / 1 h / 24 h) before starting; access needs the QR token or PIN.
- **Smart resume**: files travel in 4 MB chunks; after a disconnect, send again and only missing chunks are sent. Browser downloads resume via HTTP Range.

## Speed
Real measured throughput is shown in *Transfers*. 1 Gbps (~125 MB/s) is only reachable on a strong Wi-Fi 5/6 link with fast storage on both devices; many phones and routers top out lower. The app uses parallel chunk streams, a low-latency Wi-Fi lock and no artificial limits, but cannot exceed the hardware/network.

## Implemented in this version
Material 3 colourful UI (System/Light/Dark/AMOLED), foreground-service transfers, mDNS discovery, QR + PIN pairing, chunked parallel transfer, per-chunk SHA-256, resume, pause/cancel, history, browser page (upload + download), group send, no file-size limit.

## Not included yet (honest list)
Wi-Fi Direct, TLS/E2E encryption, internet links via cloud backend (Go), secure vault, built-in file manager, folder sharing, native Windows app, automated tests. See SECURITY.md.
