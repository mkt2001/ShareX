# Security notes

## Current protections
- Random 128-bit session token (QR) and 6-digit PIN; constant-time comparison.
- Rate limit: 8 failed attempts per minute per IP, then HTTP 429.
- Optional link expiry (HTTP 410 afterwards).
- File names sanitised (no path traversal); uploads only go to the app's private incoming folder, then to Downloads/ShareX.
- Per-chunk SHA-256 verification (app-to-app); final file SHA-256 recorded in History.
- Received files are never executed or opened automatically.

## Known limitations (v1)
- Traffic is plain HTTP on the local network (no TLS/E2E yet). Use trusted Wi-Fi/hotspot only.
- Browser uploads cannot hash chunks on plain HTTP (WebCrypto needs HTTPS); TCP checksums only.
- No encrypted vault, no device trust list yet.

## Roadmap
TLS 1.3 with a pinned self-signed certificate (fingerprint in the QR), AES-256-GCM payload encryption, Keystore-backed trusted devices.

## Audit checklist
[x] Token + PIN auth  [x] Rate limiting  [x] Path traversal protection  [x] Integrity checks
[ ] TLS  [ ] E2E encryption  [ ] Dependency scanning in CI  [ ] Fuzzing of HTTP parser
