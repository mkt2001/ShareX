Open an issue first, keep changes small, run `gradle assembleDebug` before a pull request.
